from fastapi import FastAPI, Request, UploadFile, File, Form, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
import sqlite3, secrets, re
from pathlib import Path
from datetime import datetime, timezone

BASE = Path(__file__).resolve().parent
DB = BASE / "esposas.db"
MEDIA = BASE / "media"
MEDIA.mkdir(exist_ok=True)

app = FastAPI(title="ESPOSAS")
app.mount("/media", StaticFiles(directory=MEDIA), name="media")

HTML = r"""<!doctype html>
<html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>ESPOSAS</title><style>
body{margin:0;background:#100c16;color:#eee;font-family:system-ui,sans-serif}header{padding:18px;text-align:center;background:#17111e;position:sticky;top:0;z-index:2}
h1{margin:0;color:#d05cff;letter-spacing:3px}.wrap{max-width:760px;margin:auto;padding:14px}.card{background:#19121f;border:1px solid #2a2032;border-radius:16px;padding:15px;margin:12px 0}
textarea,input,select{width:100%;box-sizing:border-box;background:#0f0b14;color:#fff;border:1px solid #3a2a45;border-radius:10px;padding:11px;margin:6px 0}
button{border:0;border-radius:10px;padding:10px 14px;background:#b84cff;color:#fff;font-weight:700;margin:4px 2px}.muted{color:#9d93a7;font-size:13px}.photo{max-width:100%;border-radius:12px;margin-top:8px}.row{display:flex;gap:8px;flex-wrap:wrap}
</style></head><body><header><h1>ESPOSAS</h1><div id="me" class="muted"></div></header><main class="wrap">
<div class="card"><h3>Publicar confesión</h3><textarea id="body" placeholder="Cuenta lo que pasó sin publicar datos personales..."></textarea>
<select id="cat"><option>General</option><option>Infidelidad</option><option>Desahogo</option><option>Consejo</option></select>
<input id="photo" type="file" accept="image/jpeg,image/png,image/webp"><button onclick="post()">Publicar</button></div><div id="feed"></div></main>
<script>
async function j(u,o){let r=await fetch(u,o),x=await r.json().catch(()=>({}));if(!r.ok)throw Error(x.detail||'Error');return x}
function esc(s){return String(s||'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
async function load(){let m=await j('/api/me');document.getElementById('me').textContent=m.alias;let ps=await j('/api/posts');document.getElementById('feed').innerHTML=ps.map(p=>`<div class="card"><b>${esc(p.alias)}</b><div class="muted">${esc(p.category)} · ${new Date(p.created).toLocaleString()}</div><p>${esc(p.body).replace(/\\n/g,'<br>')}</p>${p.photo?`<img class="photo" src="${p.photo}">`:''}<div class="row"><button onclick="like(${p.id})">❤️ ${p.likes}</button><button onclick="comment(${p.id})">💬 ${p.comments}</button><button onclick="reportp(${p.id})">⚑ Reportar</button><button onclick="msg('${esc(p.alias)}')">✉ Mensaje</button></div>${p.comments_list.map(c=>`<div class="muted"><b>${esc(c.alias)}</b>: ${esc(c.body)}</div>`).join('')}</div>`).join('')}
async function post(){let f=new FormData();f.append('body',body.value);f.append('category',cat.value);let p=photo.files[0];if(p)f.append('photo',p);try{await j('/api/posts',{method:'POST',body:f});body.value='';photo.value='';load()}catch(e){alert(e.message)}}
async function like(id){try{await j('/api/posts/'+id+'/like',{method:'POST'});load()}catch(e){alert(e.message)}}
async function comment(id){let b=prompt('Comentario:');if(b)try{await j('/api/posts/'+id+'/comment',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({body:b})});load()}catch(e){alert(e.message)}}
async function reportp(id){if(confirm('¿Reportar esta publicación?')){await j('/api/posts/'+id+'/report',{method:'POST'});load()}}
async function msg(other){let b=prompt('Mensaje para '+other+':');if(b)try{await j('/api/messages/'+encodeURIComponent(other),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({body:b})});alert('Mensaje enviado.')}catch(e){alert(e.message)}}
load()
</script></body></html>"""

BLOCKED=[r"https?://",r"www\.",r"@[A-Za-z0-9_]{3,}",r"\b\d{10}\b",r"\b\d{3}[-.\s]\d{3}[-.\s]\d{4}\b",r"\b(?:\d{1,3}\.){3}\d{1,3}\b"]

def now(): return datetime.now(timezone.utc).isoformat()
def clean(s, n=2000):
    s=(s or "").strip()
    if len(s)>n: raise HTTPException(400,"Texto demasiado largo.")
    if any(re.search(p,s,re.I) for p in BLOCKED): raise HTTPException(400,"No publiques teléfonos, enlaces, usuarios de redes o IP.")
    return s

def db():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c

def init():
    c=db()
    c.executescript("""CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,alias TEXT UNIQUE,created TEXT);
    CREATE TABLE IF NOT EXISTS posts(id INTEGER PRIMARY KEY,user_id INTEGER,body TEXT,photo TEXT,category TEXT,created TEXT,reports INTEGER DEFAULT 0,hidden INTEGER DEFAULT 0);
    CREATE TABLE IF NOT EXISTS comments(id INTEGER PRIMARY KEY,post_id INTEGER,user_id INTEGER,body TEXT,created TEXT);
    CREATE TABLE IF NOT EXISTS likes(post_id INTEGER,user_id INTEGER,UNIQUE(post_id,user_id));
    CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY,sender TEXT,receiver TEXT,body TEXT,created TEXT,reported INTEGER DEFAULT 0);
    CREATE TABLE IF NOT EXISTS blocks(blocker TEXT,blocked TEXT,UNIQUE(blocker,blocked));""")
    c.commit();c.close()
init()

@app.middleware("http")
async def session(request: Request, call_next):
    alias=request.cookies.get("esposas_alias") or "Anonimo_"+secrets.token_hex(3)
    request.state.alias=alias
    c=db()
    c.execute("INSERT OR IGNORE INTO users(alias,created) VALUES(?,?)",(alias,now()))
    c.commit();c.close()
    response=await call_next(request)
    if "esposas_alias" not in request.cookies:
        response.set_cookie("esposas_alias",alias,httponly=True,samesite="lax",secure=True,max_age=31536000)
    return response

def me(request): return request.state.alias

@app.get("/",response_class=HTMLResponse)
def home(): return HTML

@app.get("/api/me")
def api_me(request:Request): return {"alias":me(request)}

@app.get("/api/posts")
def posts():
    c=db(); rows=c.execute("""SELECT p.*,u.alias,(SELECT COUNT(*) FROM likes l WHERE l.post_id=p.id) likes,
    (SELECT COUNT(*) FROM comments x WHERE x.post_id=p.id) comments FROM posts p JOIN users u ON u.id=p.user_id
    WHERE p.hidden=0 ORDER BY p.id DESC LIMIT 100""").fetchall()
    out=[]
    for r in rows:
        cs=c.execute("SELECT x.body,u.alias,x.created FROM comments x JOIN users u ON u.id=x.user_id WHERE x.post_id=? ORDER BY x.id",(r["id"],)).fetchall()
        out.append(dict(r)|{"comments_list":[dict(x) for x in cs]})
    c.close();return out

@app.post("/api/posts")
async def create_post(request:Request,body:str=Form(...),category:str=Form("General"),photo:UploadFile|None=File(None)):
    body=clean(body,4000)
    if not body: raise HTTPException(400,"Escribe una confesión.")
    path=None
    if photo and photo.filename:
        if not (photo.content_type or "").startswith("image/"): raise HTTPException(400,"Debe ser una imagen.")
        data=await photo.read()
        if len(data)>5*1024*1024: raise HTTPException(400,"La imagen supera 5 MB.")
        ext=Path(photo.filename).suffix.lower()
        if ext not in [".jpg",".jpeg",".png",".webp"]: raise HTTPException(400,"Formato no permitido.")
        name=secrets.token_hex(12)+ext;(MEDIA/name).write_bytes(data);path="/media/"+name
    c=db();uid=c.execute("SELECT id FROM users WHERE alias=?",(me(request),)).fetchone()["id"]
    c.execute("INSERT INTO posts(user_id,body,photo,category,created) VALUES(?,?,?,?,?)",(uid,body,path,category,now()))
    c.commit();c.close();return {"ok":True}

@app.post("/api/posts/{pid}/like")
def like(pid:int,request:Request):
    c=db();uid=c.execute("SELECT id FROM users WHERE alias=?",(me(request),)).fetchone()["id"]
    try:c.execute("INSERT INTO likes(post_id,user_id) VALUES(?,?)",(pid,uid))
    except sqlite3.IntegrityError:c.execute("DELETE FROM likes WHERE post_id=? AND user_id=?",(pid,uid))
    c.commit();c.close();return {"ok":True}

@app.post("/api/posts/{pid}/comment")
async def comment(pid:int,request:Request):
    b=clean((await request.json()).get("body",""),1000)
    if not b: raise HTTPException(400,"Comentario vacío.")
    c=db();uid=c.execute("SELECT id FROM users WHERE alias=?",(me(request),)).fetchone()["id"]
    c.execute("INSERT INTO comments(post_id,user_id,body,created) VALUES(?,?,?,?)",(pid,uid,b,now()));c.commit();c.close();return {"ok":True}

@app.post("/api/posts/{pid}/report")
def report(pid:int):
    c=db();c.execute("UPDATE posts SET reports=reports+1 WHERE id=?",(pid,));c.execute("UPDATE posts SET hidden=1 WHERE id=? AND reports>=3",(pid,));c.commit();c.close();return {"ok":True}

@app.get("/api/messages/{other}")
def get_messages(other:str,request:Request):
    a=me(request);c=db()
    if c.execute("SELECT 1 FROM blocks WHERE (blocker=? AND blocked=?) OR (blocker=? AND blocked=?)",(a,other,other,a)).fetchone(): c.close();raise HTTPException(403,"Usuario bloqueado.")
    r=c.execute("SELECT sender,receiver,body,created FROM messages WHERE (sender=? AND receiver=?) OR (sender=? AND receiver=?) ORDER BY id",(a,other,other,a)).fetchall();c.close();return [dict(x) for x in r]

@app.post("/api/messages/{other}")
async def send_message(other:str,request:Request):
    a=me(request);b=clean((await request.json()).get("body",""),2000)
    if not b: raise HTTPException(400,"Mensaje vacío.")
    c=db()
    if c.execute("SELECT 1 FROM blocks WHERE (blocker=? AND blocked=?) OR (blocker=? AND blocked=?)",(a,other,other,a)).fetchone(): c.close();raise HTTPException(403,"Usuario bloqueado.")
    c.execute("INSERT INTO messages(sender,receiver,body,created) VALUES(?,?,?,?)",(a,other,b,now()));c.commit();c.close();return {"ok":True}

@app.post("/api/block/{other}")
def block(other:str,request:Request):
    c=db();c.execute("INSERT OR IGNORE INTO blocks(blocker,blocked) VALUES(?,?)",(me(request),other));c.commit();c.close();return {"ok":True}
