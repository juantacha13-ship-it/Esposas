# ESPOSAS — servidor inicial

Este paquete conecta la interfaz con una base de datos SQLite para que varias personas puedan usar el mismo servidor.

## Ejecutar en una computadora/servidor
1. Instala Python 3.11+.
2. En esta carpeta ejecuta:
   python -m pip install -r requirements.txt
3. Ejecuta:
   python -m uvicorn app.main:app --host 0.0.0.0 --port 8000
4. Abre http://127.0.0.1:8000/index.html

## Importante para hacerlo público
Todavía falta desplegarlo en un hosting con HTTPS. No compartas el servidor de desarrollo directamente en Internet.
Para producción conviene añadir: autenticación/sesiones más robustas, HTTPS, límites de velocidad, almacenamiento externo de fotos, copias de seguridad, moderación de imágenes, panel de moderación, borrado de cuentas/datos y política de privacidad.

La app prohíbe desde el backend teléfonos, URLs, usuarios de redes y direcciones IP en publicaciones/mensajes, y permite reportar/bloquear.
