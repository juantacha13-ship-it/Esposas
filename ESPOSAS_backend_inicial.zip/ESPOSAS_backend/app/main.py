
from fastapi import FastAPI, Request, UploadFile, File, Form, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
import sqlite3, secrets, re
from pathlib import Path
from datetime import datetime, timezone

BASE = Path(__file__).resolve().parent
DB = BASE / "esposas.db"
MEDIA = BASE / "static" / "media"
MEDIA.mkdir(parents=True, exist_ok=True)

app = FastAPI(title="ESPOSAS API")
app.mount("/media", StaticFiles(directory=MEDIA), name="media")

BLOCKED = [
    r"https?://", r"www\.", r"@[A-Za-z0-9_]{3,}",
    r"\b\d{10}\b", r"\b\d{3}[-.\s]\d{3}[-.\s]\d{4}\b",
    r"\b(?:\d{1,3}\.){3}\d{1,3}\b"
]

def clean_text(text: str, max_len=2000):
    text = (text or "").strip()
    if len(text) > max_len:
        raise HTTPException(400, "Texto demasiado largo.")
    if any(re.search(p, text, re.I) for p in BLOCKED):
        raise HTTPException(400, "No publiques teléfonos, enlaces, usuarios de redes o direcciones IP.")
    return text

def db():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    return con

def init():
    con = db()
    con.executescript("""
    CREATE TABLE IF NOT EXISTS users(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      alias TEXT UNIQUE NOT NULL,
      created TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS posts(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      body TEXT NOT NULL,
      photo TEXT,
      category TEXT NOT NULL,
      created TEXT NOT NULL,
      reports INTEGER DEFAULT 0,
      hidden INTEGER DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS comments(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      post_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      body TEXT NOT NULL,
      created TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS likes(
      post_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      UNIQUE(post_id,user_id)
    );
    CREATE TABLE IF NOT EXISTS messages(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      sender TEXT NOT NULL,
      receiver TEXT NOT NULL,
      body TEXT NOT NULL,
      created TEXT NOT NULL,
      reported INTEGER DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS blocks(
      blocker TEXT NOT NULL,
      blocked TEXT NOT NULL,
      UNIQUE(blocker,blocked)
    );
    """)
    con.commit(); con.close()

init()

def now():
    return datetime.now(timezone.utc).isoformat()

def current_user(request: Request):
    alias = request.cookies.get("esposas_alias")
    if not alias:
        alias = "Anonimo_" + secrets.token_hex(3)
    con = db()
    row = con.execute("SELECT id,alias FROM users WHERE alias=?", (alias,)).fetchone()
    if not row:
        con.execute("INSERT INTO users(alias,created) VALUES(?,?)",(alias,now()))
        con.commit()
    con.close()
    return alias

@app.get("/api/me")
def me(request: Request):
    alias = current_user(request)
    response = {"alias": alias}
    return response

@app.middleware("http")
async def alias_cookie(request: Request, call_next):
    response = await call_next(request)
    if "esposas_alias" not in request.cookies:
        # Cookie is set after current_user creates it; use a fresh alias.
        response.set_cookie("esposas_alias", "Anonimo_" + secrets.token_hex(3),
                            httponly=True, samesite="lax", secure=False, max_age=31536000)
    return response

@app.get("/api/posts")
def list_posts(request: Request):
    alias = current_user(request)
    con = db()
    rows = con.execute("""
      SELECT p.*, u.alias,
      (SELECT COUNT(*) FROM likes l WHERE l.post_id=p.id) likes,
      (SELECT COUNT(*) FROM comments c WHERE c.post_id=p.id) comments
      FROM posts p JOIN users u ON u.id=p.user_id
      WHERE p.hidden=0 ORDER BY p.id DESC LIMIT 100
    """).fetchall()
    out=[]
    for r in rows:
        comments=con.execute("""
          SELECT c.body,u.alias,c.created FROM comments c
          JOIN users u ON u.id=c.user_id WHERE c.post_id=? ORDER BY c.id
        """,(r["id"],)).fetchall()
        out.append(dict(r) | {"comments_list":[dict(c) for c in comments]})
    con.close()
    return out

@app.post("/api/posts")
async def create_post(request: Request, body: str = Form(...), category: str = Form("General"), photo: UploadFile|None = File(None)):
    alias = current_user(request)
    body = clean_text(body, 4000)
    if not body:
        raise HTTPException(400,"Escribe una confesión.")
    photo_path=None
    if photo and photo.filename:
        if not (photo.content_type or "").startswith("image/"):
            raise HTTPException(400,"El archivo debe ser una imagen.")
        data=await photo.read()
        if len(data)>5*1024*1024:
            raise HTTPException(400,"La imagen supera 5 MB.")
        ext=Path(photo.filename).suffix.lower()
        if ext not in [".jpg",".jpeg",".png",".webp"]:
            raise HTTPException(400,"Formato de imagen no permitido.")
        name=secrets.token_hex(12)+ext
        (MEDIA/name).write_bytes(data)
        photo_path="/media/"+name
    con=db()
    uid=con.execute("SELECT id FROM users WHERE alias=?",(alias,)).fetchone()["id"]
    con.execute("INSERT INTO posts(user_id,body,photo,category,created) VALUES(?,?,?,?,?)",
                (uid,body,photo_path,category,now()))
    con.commit(); con.close()
    return {"ok":True}

@app.post("/api/posts/{post_id}/like")
def like(post_id:int, request:Request):
    alias=current_user(request); con=db()
    uid=con.execute("SELECT id FROM users WHERE alias=?",(alias,)).fetchone()["id"]
    try:
        con.execute("INSERT INTO likes(post_id,user_id) VALUES(?,?)",(post_id,uid))
        con.commit()
    except sqlite3.IntegrityError:
        con.execute("DELETE FROM likes WHERE post_id=? AND user_id=?",(post_id,uid)); con.commit()
    con.close(); return {"ok":True}

@app.post("/api/posts/{post_id}/comment")
async def comment(post_id:int, request:Request):
    data=await request.json()
    body=clean_text(data.get("body",""),1000)
    if not body: raise HTTPException(400,"Comentario vacío.")
    alias=current_user(request); con=db()
    uid=con.execute("SELECT id FROM users WHERE alias=?",(alias,)).fetchone()["id"]
    con.execute("INSERT INTO comments(post_id,user_id,body,created) VALUES(?,?,?,?)",(post_id,uid,body,now()))
    con.commit(); con.close(); return {"ok":True}

@app.post("/api/posts/{post_id}/report")
def report(post_id:int):
    con=db(); con.execute("UPDATE posts SET reports=reports+1 WHERE id=?",(post_id,))
    con.execute("UPDATE posts SET hidden=1 WHERE id=? AND reports>=3",(post_id,))
    con.commit(); con.close(); return {"ok":True}

@app.get("/api/messages/{other}")
def messages(other:str, request:Request):
    me=current_user(request); con=db()
    blocked=con.execute("SELECT 1 FROM blocks WHERE (blocker=? AND blocked=?) OR (blocker=? AND blocked=?)",
                        (me,other,other,me)).fetchone()
    if blocked: con.close(); raise HTTPException(403,"Usuario bloqueado.")
    rows=con.execute("""SELECT sender,receiver,body,created FROM messages
      WHERE (sender=? AND receiver=?) OR (sender=? AND receiver=?)
      ORDER BY id""",(me,other,other,me)).fetchall()
    con.close(); return [dict(x) for x in rows]

@app.post("/api/messages/{other}")
async def send_message(other:str, request:Request):
    me=current_user(request)
    data=await request.json()
    body=clean_text(data.get("body",""),2000)
    if not body: raise HTTPException(400,"Mensaje vacío.")
    con=db()
    blocked=con.execute("SELECT 1 FROM blocks WHERE (blocker=? AND blocked=?) OR (blocker=? AND blocked=?)",
                        (me,other,other,me)).fetchone()
    if blocked: con.close(); raise HTTPException(403,"Usuario bloqueado.")
    con.execute("INSERT INTO messages(sender,receiver,body,created) VALUES(?,?,?,?)",(me,other,body,now()))
    con.commit(); con.close(); return {"ok":True}

@app.post("/api/block/{other}")
def block(other:str, request:Request):
    me=current_user(request); con=db()
    con.execute("INSERT OR IGNORE INTO blocks(blocker,blocked) VALUES(?,?)",(me,other))
    con.commit(); con.close(); return {"ok":True}
